OK_FORMAT = True

test = {   'name': 'q5_4',
    'points': [5],
    'suites': [   {   'cases': [   {   'code': '>>> sales.sort(0)\n'
                                               'box ID | fruit name | count sold | price per fruit ($)\n'
                                               '25274  | apple      | 0          | 0.8\n'
                                               '26187  | strawberry | 25         | 0.15\n'
                                               '43566  | peach      | 17         | 0.8\n'
                                               '48800  | orange     | 35         | 0.6\n'
                                               '52357  | strawberry | 102        | 0.25\n'
                                               '53686  | kiwi       | 3          | 0.5\n'
                                               '57181  | strawberry | 101        | 0.2\n'
                                               '57930  | grape      | 355        | 0.06',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
