OK_FORMAT = True

test = {   'name': 'q4_3',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> len(first_nine_waiting_times)\n9', 'hidden': False, 'locked': False},
                                   {'code': '>>> total_waiting_time_until_tenth\n633', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
