OK_FORMAT = True

test = {   'name': 'q2_1',
    'points': [0, 4],
    'suites': [   {   'cases': [   {   'code': '>>> # It looks like you wrote:\n>>> #   some_numbers.item(3)\n>>> # But the third element has index 2, not 3.\n>>> third_element != -10\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> third_element == -6\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
