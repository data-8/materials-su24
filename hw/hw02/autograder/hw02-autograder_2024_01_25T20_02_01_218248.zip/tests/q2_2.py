OK_FORMAT = True

test = {   'name': 'q2_2',
    'points': [1, 1, 1, 1],
    'suites': [   {   'cases': [   {'code': '>>> elements_of_some_numbers.column(0).item(2) == "third"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> elements_of_some_numbers.column(0).item(3) == "fourth"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> elements_of_some_numbers.column(1).item(0) == 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> elements_of_some_numbers.column(1).item(3) == 3\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
