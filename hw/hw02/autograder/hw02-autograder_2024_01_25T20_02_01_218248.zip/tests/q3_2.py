OK_FORMAT = True

test = {   'name': 'q3_2',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> # products should be an array!\n>>> len(products) == 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.allclose(products, np.array([6594, -663168, 66603205994, 39250]))\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
