OK_FORMAT = True

test = {   'name': 'q1_9',
    'points': [0, 0, 5],
    'suites': [   {   'cases': [   {   'code': '>>> # Make sure simulated_gains_split is an array.\n>>> import numpy as np\n>>> type(simulated_gains_split) == np.ndarray\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> len(simulated_gains_split) == 10000\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.count_nonzero(simulated_gains_split >= -200) == 10000\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
