OK_FORMAT = True

test = {   'name': 'q1_2',
    'points': [0, 4],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure your column names are correct\n>>> wheel.labels[2] == "Winnings: Red"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sum(wheel.column("Winnings: Red")) == -2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
