OK_FORMAT = True

test = {   'name': 'q1_7',
    'points': [2, 1, 1],
    'suites': [   {   'cases': [   {'code': ">>> dollar_bet_on_split('5') == 17\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> dollar_bet_on_split('6') == 17\nTrue", 'hidden': True, 'locked': False},
                                   {'code': ">>> dollar_bet_on_split('10') == -1\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
