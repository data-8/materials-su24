OK_FORMAT = True

test = {   'name': 'q1_5',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {   'code': '>>> # Make sure simulated_gains_red is an array.\n>>> import numpy as np\n>>> type(simulated_gains_red) == np.ndarray\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> len(simulated_gains_red) == 10000\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.count_nonzero(simulated_gains_red <= 100) == 10000\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
