OK_FORMAT = True

test = {   'name': 'q4_1',
    'points': [0, 0, 1, 2],
    'suites': [   {   'cases': [   {'code': '>>> # The array should have length 2\n>>> len(deck_model_probabilities) == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # The elements in the array should add up to 1.\n>>> sum(deck_model_probabilities) == 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> deck_model_probabilities.item(0) == 4/13\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> deck_model_probabilities.item(1) == 9/13\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
