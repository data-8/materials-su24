OK_FORMAT = True

test = {   'name': 'q1_6',
    'points': [0, 2],
    'suites': [   {   'cases': [   {'code': '>>> type(loss_more_than_50) == bool\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> loss_more_than_50 == True\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
