OK_FORMAT = True

test = {   'name': 'q1_3',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {   'code': '>>> # If this test isn\'t passing, try running the cells from the top.\n>>> set(["Pocket", "Color", "Winnings: Red"]) == set(ten_bets.labels)\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> # Checks that ten_bets doesn't have the same number of rows as wheel\n>>> ten_bets.num_rows != wheel.num_rows\nTrue",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> ten_bets.num_rows == 10\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
