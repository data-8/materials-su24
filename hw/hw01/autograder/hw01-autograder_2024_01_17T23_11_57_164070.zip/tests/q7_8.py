OK_FORMAT = True

test = {   'name': 'q7_8',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> type(secret) == str\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(secret)\n8', 'hidden': False, 'locked': False},
                                   {'code': ">>> secret == 'beepboop'\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
