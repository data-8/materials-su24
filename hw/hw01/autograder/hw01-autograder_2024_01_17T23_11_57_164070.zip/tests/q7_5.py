OK_FORMAT = True

test = {'name': 'q7_5', 'points': [4], 'suites': [{'cases': [{'code': '>>> acceptable == 2\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
