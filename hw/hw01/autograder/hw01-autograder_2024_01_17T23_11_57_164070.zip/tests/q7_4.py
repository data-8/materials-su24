OK_FORMAT = True

test = {'name': 'q7_4', 'points': [4], 'suites': [{'cases': [{'code': '>>> gradescope == 576157\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
