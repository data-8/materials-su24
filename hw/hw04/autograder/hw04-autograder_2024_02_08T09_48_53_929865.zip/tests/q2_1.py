OK_FORMAT = True

test = {   'name': 'q2_1',
    'points': [0, 0, 0, 0, 4, 5],
    'suites': [   {   'cases': [   {'code': '>>> job_titles.num_columns\n2', 'hidden': False, 'locked': False},
                                   {'code': '>>> job_titles.num_rows\n6', 'hidden': False, 'locked': False},
                                   {   'code': '>>> # Make sure that you have the correct column labels!\n>>> np.asarray(job_titles.labels).item(1) != "Job full_array"\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> # Make sure that you have the correct column labels!\n>>> np.asarray(job_titles.labels).item(1) == "Jobs"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> len(job_titles.where('Organization Group', 'Culture & Recreation').column('Jobs').item(0))\n3938", 'hidden': True, 'locked': False},
                                   {'code': ">>> len(job_titles.where('Organization Group', 'Public Protection').column('Jobs').item(0))\n8361", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
