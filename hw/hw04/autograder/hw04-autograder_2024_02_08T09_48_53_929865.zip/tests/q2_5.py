OK_FORMAT = True

test = {   'name': 'q2_5',
    'points': [2, 2, 5],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure that your final answer is a number\n>>> isinstance(num_over_125k, int)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Make sure that your answer makes sense given the sf table\n>>> 0 <= num_over_125k <= 51\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> num_over_125k == 23\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
