OK_FORMAT = True

test = {   'name': 'q1_7',
    'points': [0, 8],
    'suites': [   {   'cases': [   {'code': '>>> # Your answer should be between 0 and 100.\n>>> 0 <= burritos_less_than_six <= 100\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 19 <= burritos_less_than_six <= 26\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
