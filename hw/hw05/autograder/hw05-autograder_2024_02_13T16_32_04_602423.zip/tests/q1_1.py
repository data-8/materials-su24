OK_FORMAT = True

test = {   'name': 'q1_1',
    'points': [1, 1],
    'suites': [   {   'cases': [{'code': '>>> sum_scores(2, 3, 6, 1)\n12', 'hidden': False, 'locked': False}, {'code': '>>> sum_scores(-2,3,5,-10)\n-4', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
