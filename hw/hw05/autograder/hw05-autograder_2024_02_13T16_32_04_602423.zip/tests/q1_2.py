OK_FORMAT = True

test = {   'name': 'q1_2',
    'points': [0, 0, 5],
    'suites': [   {   'cases': [   {'code': '>>> final_scores.num_columns\n3', 'hidden': False, 'locked': False},
                                   {'code': ">>> set(['Opponent', 'Cal Score', 'Opponent Score']) == set(final_scores.labels)\nTrue", 'hidden': False, 'locked': False},
                                   {   'code': '>>> final_scores.take(range(5, 11))\n'
                                               'Opponent         | Cal Score | Opponent Score\n'
                                               'Oregon State     | 40        | 52\n'
                                               'Utah             | 14        | 34\n'
                                               'USC              | 49        | 50\n'
                                               'Oregon           | 19        | 63\n'
                                               'Washington State | 42        | 39\n'
                                               'Stanford         | 27        | 15',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
