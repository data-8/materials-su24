OK_FORMAT = True

test = {   'name': 'q0_1',
    'points': [0, 1],
    'suites': [   {   'cases': [   {'code': '>>> # Make sure that your answer is a string\n>>> type(secret_phrase) == str \nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> secret_phrase == "clover"\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
