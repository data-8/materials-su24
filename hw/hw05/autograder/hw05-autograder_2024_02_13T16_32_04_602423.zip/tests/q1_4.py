OK_FORMAT = True

test = {   'name': 'q1_4',
    'points': [0, 0, 5, 5],
    'suites': [   {   'cases': [   {'code': '>>> 0 <= cal_wins <= 13\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 <= cal_losses <= 13\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> cal_wins - cal_losses\n-1', 'hidden': True, 'locked': False},
                                   {'code': '>>> [results_array.item(6), results_array.item(1), results_array.item(5)] == [True, True, True]\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
