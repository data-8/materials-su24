OK_FORMAT = True

test = {   'name': 'q2_4',
    'points': [0, 0, 4],
    'suites': [   {   'cases': [   {'code': '>>> # visualization should be assigned to an integer.\n>>> type(visualization) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Make sure visualization is assigned to 1, 2 or 3.\n>>> 1 <= visualization <= 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> visualization == 3\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
