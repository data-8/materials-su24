OK_FORMAT = True

test = {   'name': 'q1_5',
    'points': [4],
    'suites': [   {   'cases': [{'code': '>>> by_pter.take(0)\nDate       | NEI     | NEI-PTER | PTER\n2009-07-01 | 10.8089 | 12.7404  | 1.9315', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
