OK_FORMAT = True

test = {   'name': 'q3_4',
    'points': [0, 0, 2, 2],
    'suites': [   {   'cases': [   {'code': '>>> boston_under_15 >= 0 and boston_under_15 <= 100\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> manila_under_15 >= 0 and manila_under_15 <= 100\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> boston_under_15 == 5 * 1.2 + 5 * 3.2 + 5 * 4.9\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> manila_under_15 == 5 * 0.6 + 5 * 1.4 + 5 * 2.2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
