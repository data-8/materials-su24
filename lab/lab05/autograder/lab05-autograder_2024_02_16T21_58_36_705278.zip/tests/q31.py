OK_FORMAT = True

test = {   'name': 'q31',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> stats = compute_statistics(full_data)\n>>> plt.close()\n>>> plt.close()\n>>> round(float(stats[0]), 2) == 26.54\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> stats = compute_statistics(full_data)\n>>> plt.close()\n>>> plt.close()\n>>> round(float(stats[1]), 2) == 4269775.77\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
