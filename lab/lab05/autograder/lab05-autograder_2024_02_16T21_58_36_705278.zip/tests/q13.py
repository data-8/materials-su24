OK_FORMAT = True

test = {   'name': 'q13',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> nacho_reaction('salsa')\n'Spicy!'", 'hidden': False, 'locked': False},
                                   {'code': ">>> nacho_reaction('cheese')\n'Cheesy!'", 'hidden': False, 'locked': False},
                                   {'code': ">>> nacho_reaction('both')\n'Wow!'", 'hidden': False, 'locked': False},
                                   {'code': ">>> nacho_reaction('neither')\n'Meh.'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
