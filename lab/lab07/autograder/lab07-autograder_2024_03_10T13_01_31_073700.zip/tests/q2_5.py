OK_FORMAT = True

test = {'name': 'q2_5', 'points': None, 'suites': [{'cases': [{'code': '>>> test_option == 4\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
