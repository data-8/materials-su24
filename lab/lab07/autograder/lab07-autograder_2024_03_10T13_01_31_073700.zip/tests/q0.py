OK_FORMAT = True

test = {'name': 'q0', 'points': None, 'suites': [{'cases': [{'code': '>>> mid_secret == "bing su"\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
