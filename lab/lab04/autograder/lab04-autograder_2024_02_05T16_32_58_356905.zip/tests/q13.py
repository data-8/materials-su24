OK_FORMAT = True

test = {   'name': 'q13',
    'points': None,
    'suites': [{'cases': [{'code': '>>> num_non_vowels("Go bears!") == 6\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
