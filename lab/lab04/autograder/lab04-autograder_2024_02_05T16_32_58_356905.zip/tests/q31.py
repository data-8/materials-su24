OK_FORMAT = True

test = {   'name': 'q31',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(some_functions)\n3', 'hidden': False, 'locked': False},
                                   {'code': '>>> # The first thing in your array may not be a function\n>>> callable(some_functions.item(0))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # The second thing in your array may not be a function\n>>> callable(some_functions.item(1))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # The third thing in your array may not be a function\n>>> callable(some_functions.item(2))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
