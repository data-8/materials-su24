OK_FORMAT = True

test = {   'name': 'q12',
    'points': None,
    'suites': [   {   'cases': [{'code': ">>> # Make sure you're using a_proportion!\n>>> np.isclose(a_percentage, 70.71067811865476)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
