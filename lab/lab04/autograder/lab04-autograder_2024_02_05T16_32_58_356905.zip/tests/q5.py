OK_FORMAT = True

test = {'name': 'q5', 'points': None, 'suites': [{'cases': [{'code': '>>> submitted\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
