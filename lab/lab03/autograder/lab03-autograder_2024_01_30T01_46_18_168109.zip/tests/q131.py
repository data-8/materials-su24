OK_FORMAT = True

test = {'name': 'q131', 'points': None, 'suites': [{'cases': [{'code': '>>> sentence_length\n896', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
