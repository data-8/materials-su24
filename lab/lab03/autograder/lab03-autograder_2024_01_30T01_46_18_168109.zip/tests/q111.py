OK_FORMAT = True

test = {'name': 'q111', 'points': None, 'suites': [{'cases': [{'code': ">>> new_word\n'matchmaker'", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
