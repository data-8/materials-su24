OK_FORMAT = True

test = {'name': 'q221', 'points': None, 'suites': [{'cases': [{'code': '>>> population_1973\n3942096442', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
