OK_FORMAT = True

test = {   'name': 'q511',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(collection_times) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(collection_times)\n744', 'hidden': False, 'locked': False},
                                   {'code': '>>> collection_times.item(12) == 43200\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> collection_times.item(37) == 133200\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
