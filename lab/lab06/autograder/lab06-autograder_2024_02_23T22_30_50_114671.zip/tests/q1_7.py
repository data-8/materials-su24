OK_FORMAT = True

test = {   'name': 'q1_7',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(model_proportions) % 2 == 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(np.unique(model_proportions))\n1', 'hidden': False, 'locked': False},
                                   {'code': '>>> sum(model_proportions) == 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> type(simulation_proportion_correct) == float\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(simulation_proportion_correct, 2)\n0.49', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(one_statistic, 2) - 0.95 < 0.05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
