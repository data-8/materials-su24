OK_FORMAT = True

test = {   'name': 'q1_8',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(simulated_statistics) == 1000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.all(simulated_statistics <= 30)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.all(simulated_statistics >= 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 <= simulation_and_statistic(model_proportions, expected_proportion_correct) <= 25\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
