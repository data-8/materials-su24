OK_FORMAT = True

test = {'name': 'q1_10', 'points': None, 'suites': [{'cases': [{'code': '>>> peer_talk == True\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
